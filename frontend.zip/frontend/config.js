window.APP_CONFIG = {
  API_BASE: 'https://api.example.com/api',
};
